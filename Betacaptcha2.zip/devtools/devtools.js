chrome.devtools.panels.create("BetaCaptcha Detector", "assets/images/logo.svg", "app/index.html");
