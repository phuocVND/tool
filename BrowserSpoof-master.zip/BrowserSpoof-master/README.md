Download the build.zip

Extract the zip file, make sure all files are in the same folder.

Fill the proxies.txt file with proxies in the corresponding format.

Now all you need to do is run spoof.exe and fill out the text fields and click the launch button!

Please create an issue  if an issue arises.

PS: Do not run an excessive amount of tasks.

By Downloading/cloning this repo you agree to not resell this software.
